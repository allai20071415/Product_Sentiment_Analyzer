# Product Sentiment Analyzer

A full-stack product review sentiment analysis system that combines review scraping, sentiment analysis, MongoDB storage, a Flask backend, and a React/Vite frontend dashboard.

## Features

- Product review collection using modular scraper classes
- Amazon and Flipkart scraper modules
- Sentiment analysis using VADER
- MongoDB database integration
- Flask REST API
- React + Vite frontend dashboard
- Sentiment charts and review tables
- Search by product name
- Health-check endpoint for the backend
- Sample review and sentiment datasets included for demonstration

## Architecture

```text
Product-Sentiment-Analyzer/
├── product_review_scraper/     # Review collection and sentiment processing
├── database/                   # MongoDB connection and data import/export utilities
├── backend/                    # Flask API and database services
├── frontend/                   # React/Vite dashboard
├── Product_Sentiment_Analyzer_Deployment_Guide.pdf
├── .env.example
├── .gitignore
└── README.md
```

## Technology Stack

- **Frontend:** React, Vite, React Router, Recharts, Lucide React
- **Backend:** Python, Flask, Flask-CORS
- **Sentiment Analysis:** VADER Sentiment
- **Database:** MongoDB / PyMongo
- **Data Processing:** Pandas
- **Scraping:** Requests, BeautifulSoup

## Requirements

Install:

- Python 3.10+
- Node.js 18+
- npm
- MongoDB (local or hosted)

## 1. Clone the Repository

```bash
git clone <YOUR_GITHUB_REPOSITORY_URL>
cd Product-Sentiment-Analyzer
```

## 2. Configure the Backend

Create a virtual environment:

### Windows

```bash
python -m venv .venv
.venv\Scripts\activate
```

### macOS/Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
```

Install backend dependencies:

```bash
pip install -r backend/requirements.txt
```

Copy `.env.example` to `backend/.env` and update the MongoDB connection values if required.

```text
MONGO_URI=mongodb://localhost:27017/
DATABASE_NAME=ProductSentimentDB
FLASK_DEBUG=False
```

`backend/.env` is intentionally ignored by Git so credentials are not committed.

## 3. Prepare the Review/Sentiment Module

```bash
pip install -r product_review_scraper/requirements.txt
```

Run the scraper when you need to collect reviews:

```bash
cd product_review_scraper
python scraper.py
```

Run sentiment analysis:

```bash
python sentiment_analysis.py
```

Return to the project root before starting the backend:

```bash
cd ..
```

## 4. Start the Flask Backend

From the project root:

```bash
python backend/app.py
```

The API runs by default at:

```text
http://127.0.0.1:5000
```

Useful endpoints:

```text
GET /                  Backend status
GET /health            Health status
GET /analyze/<name>    Analyze a product
```

## 5. Start the React Frontend

Open a second terminal:

```bash
cd frontend
npm install
npm run dev
```

Vite will display the local development URL, normally:

```text
http://localhost:5173
```

The frontend requests sentiment data from the Flask backend at `http://127.0.0.1:5000`.

## Database

The `database/` directory contains MongoDB connection helpers, import scripts, sample CSV data, and a sample database export.

Install database-specific dependencies if you need to use those utilities:

```bash
pip install -r database/requirements.txt
```

## Sample Data

The repository includes sample CSV/JSON data so the project can be inspected without committing local virtual environments or database credentials.

## Testing

The scraper module contains a test file:

```bash
cd product_review_scraper
python -m pytest test_scraper.py
```

## GitHub Security

Do **not** commit:

- `backend/.env`
- API keys
- MongoDB passwords or private connection strings
- Session cookies or authentication tokens
- `.venv/`
- `node_modules/`
- Python cache files

A `.gitignore` file is included for these cases.

## Deployment Documentation

See `Product_Sentiment_Analyzer_Deployment_Guide.pdf` for the project's deployment guidance.

## License

Add the license of your choice before publishing the project publicly. MIT is a common option for open-source projects.
